# File: repair_portal/inspection/config/docs.py
# Updated: 2025-06-27
# Purpose: Documentation routing for Inspection module.
