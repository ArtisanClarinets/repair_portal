# QA Notifications

## Notifications provided:
- NCR Overdue Notification: Alerts techs if NCR open >48h
- Follow-up Due Notification: Notifies client and techs when complimentary post-sale check-up is due (~90 days)
- Critical Fail Notification: Alerts senior tech when critical failure detected

## Automation
- Triggers are defined by Frappe notification system conditions
- Recipients routed by role

## Last Updated
2025-06-27
