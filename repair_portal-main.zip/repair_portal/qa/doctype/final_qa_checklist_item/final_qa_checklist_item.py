# File: repair_portal/repair_portal/qa/doctype/final_qa_checklist_item/final_qa_checklist_item.py
# Updated: 2025-06-13
# Version: 1.1
# Purpose: Controller for Final QA Checklist Item Doctype

from frappe.model.document import Document


class FinalQaChecklistItem(Document):
    pass
