"""
File: repair_portal/client_profile/doctype/consent_log_entry/consent_log_entry.py
Updated: 2025-06-16
Version: 1.0.0
Purpose: Python controller for Consent Log Entry DocType (Table, istable=1)
"""

from frappe.model.document import Document


class ConsentLogEntry(Document):
    pass
