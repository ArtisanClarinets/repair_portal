"""
File: repair_portal/client_profile/doctype/consent_log/consent_log.py
Updated: 2025-06-16
Version: 1.0.0
Purpose: Python controller for Consent Log DocType (Table, istable=1)
"""

from frappe.model.document import Document


class ConsentLog(Document):
    pass
