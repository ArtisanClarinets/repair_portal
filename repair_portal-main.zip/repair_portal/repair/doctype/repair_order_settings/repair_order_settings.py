# File: repair_portal/repair/doctype/repair_order_settings/repair_order_settings.py
# Updated: 2025-06-15
# Version: 1.0
# Purpose: Controller for Repair Order Settings (Single DocType)

from frappe.model.document import Document


class RepairOrderSettings(Document):
    pass
