# File: repair_portal/repair_portal/lab/doctype/measurement_entry/measurement_entry.py
# Updated: 2025-06-28
# Version: 1.0
# Purpose: Server-side logic for Measurement Entry child table

from frappe.model.document import Document


class MeasurementEntry(Document):
    pass
