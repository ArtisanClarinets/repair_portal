# File: repair_portal/lab/doctype/tone_fitness_entry/tone_fitness_entry.py
# Updated: 2025-06-17
# Version: 1.0
# Purpose: Child table for tone fitness trend entries.

"""Child table for tone fitness trend entries."""

from frappe.model.document import Document


class ToneFitnessEntry(Document):
    pass
