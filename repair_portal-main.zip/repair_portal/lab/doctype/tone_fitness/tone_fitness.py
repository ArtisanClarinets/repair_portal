# File: repair_portal/lab/doctype/tone_fitness/tone_fitness.py
# Updated: 2025-06-17
# Version: 1.0
# Purpose: Parent DocType for brightness vs warmth measurements.

"""Parent DocType for brightness vs warmth measurements."""

from frappe.model.document import Document


class ToneFitness(Document):
    pass
