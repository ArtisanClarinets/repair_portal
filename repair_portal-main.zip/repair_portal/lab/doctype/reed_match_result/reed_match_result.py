# File: repair_portal/lab/doctype/reed_match_result/reed_match_result.py
# Updated: 2025-06-17
# Version: 1.0
# Purpose: Parent DocType storing reed match results.

"""Parent DocType storing reed match results."""

from frappe.model.document import Document


class ReedMatchResult(Document):
    pass
