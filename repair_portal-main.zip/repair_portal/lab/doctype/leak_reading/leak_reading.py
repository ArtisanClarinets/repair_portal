# File: repair_portal/lab/doctype/leak_reading/leak_reading.py
# Updated: 2025-06-17
# Version: 1.0
# Purpose: Child table for leak test readings.

"""Child table for leak test readings."""

from frappe.model.document import Document


class LeakReading(Document):
    pass
