# File: repair_portal/lab/doctype/impedance_peak/impedance_peak.py
# Updated: 2025-06-17
# Version: 1.0
# Purpose: Child table for impedance peak data.

"""Child table for impedance peak data."""

from frappe.model.document import Document


class ImpedancePeak(Document):
    pass
