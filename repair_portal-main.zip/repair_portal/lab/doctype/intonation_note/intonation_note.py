# File: repair_portal/lab/doctype/intonation_note/intonation_note.py
# Updated: 2025-06-17
# Version: 1.0
# Purpose: Child table for individual intonation readings.

"""Child table for individual intonation readings."""

from frappe.model.document import Document


class IntonationNote(Document):
    pass
