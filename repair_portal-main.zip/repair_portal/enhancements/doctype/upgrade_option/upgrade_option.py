from frappe.model.document import Document


class UpgradeOption(Document):
    pass
