# repair_portal/instrument_setup/doctype/instrument_profile/instrument_profile.py
# Date Updated: 2025-06-16
# Version: 1.0
# Purpose: Controller for Instrument Profile child Doctype in Instrument Setup

from frappe.model.document import Document


class InstrumentProfile(Document):
    pass
