# repair_portal/instrument_setup/doctype/consent_log_entry/consent_log_entry.py
# Date Updated: 2025-06-16
# Version: 1.0
# Purpose: Controller for Consent Log Entry child Doctype

from frappe.model.document import Document


class ConsentLogEntry(Document):
    pass
