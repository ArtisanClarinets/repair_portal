# repair_portal/instrument_profile/doctype/document_history/__init__.py
# Updated: 2025-07-01
# Purpose: Marks Document History as a Python module for Frappe child table.
