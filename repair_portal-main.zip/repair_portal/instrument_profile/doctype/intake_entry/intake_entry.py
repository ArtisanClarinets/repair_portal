# File: repair_portal/repair_portal/instrument_profile/doctype/intake_entry/intake_entry.py
# Updated: 2025-06-26
# Version: 1.0
# Purpose: Child Table for Instrument Intake

from frappe.model.document import Document


class IntakeEntry(Document):
    pass
