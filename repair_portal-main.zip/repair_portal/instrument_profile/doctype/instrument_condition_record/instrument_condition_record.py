# File: repair_portal/instrument_profile/doctype/instrument_condition_record/instrument_condition_record.py
# Created: 2025-06-13
# Version: 1.0
# Purpose: Child table to log instrument condition evaluations

from frappe.model.document import Document


class InstrumentConditionRecord(Document):
    pass
