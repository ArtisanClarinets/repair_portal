# repair_portal/instrument_profile/doctype/warranty_modification_log/warranty_modification_log.py
# Updated: 2025-06-15
# Version: 1.0
# Purpose: Backend controller for warranty change logs

from frappe.model.document import Document


class WarrantyModificationLog(Document):
    pass
