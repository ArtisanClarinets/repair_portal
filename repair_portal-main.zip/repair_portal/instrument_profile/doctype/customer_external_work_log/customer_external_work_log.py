# repair_portal/instrument_profile/doctype/customer_external_work_log/customer_external_work_log.py
# Updated: 2025-06-15
# Version: 1.0
# Purpose: Controller for customer-submitted repair history logs

from frappe.model.document import Document


class CustomerExternalWorkLog(Document):
    pass
