# repair_portal/instrument_profile/doctype/external_work_logs/external_work_logs.py
# Date Updated: 2025-06-16
# Version: 1.0
# Purpose: Controller for External Work Logs child table

from frappe.model.document import Document


class ExternalWorkLogs(Document):
    pass
