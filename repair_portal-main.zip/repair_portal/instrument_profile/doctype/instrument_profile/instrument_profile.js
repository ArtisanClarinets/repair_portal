frappe.ui.form.on('Instrument Profile', {
  refresh(frm) {
    // Show status badges
    if (frm.doc.status) {
      frm.dashboard.clear_headline();
      frm.dashboard.set_headline(__('Instrument Status: {0}', [frm.doc.status]));
    }

    // Show buttons for manual actions if permitted
    if (frm.doc.status === 'Awaiting Pickup') {
      frm.add_custom_button(__('Deliver Instrument'), () => {
        frappe.call({
          method: 'frappe.model.workflow.apply_workflow',
          args: {
            doc: frm.doc,
            action: 'Deliver'
          },
          callback: () => {
            frm.reload_doc();
          }
        });
      }, __('Actions'));
    }

    if (frm.doc.status === 'Delivered') {
      frm.add_custom_button(__('Archive'), () => {
        frappe.call({
          method: 'frappe.model.workflow.apply_workflow',
          args: {
            doc: frm.doc,
            action: 'Archive'
          },
          callback: () => {
            frm.reload_doc();
          }
        });
      }, __('Actions'));
    }
  }
});