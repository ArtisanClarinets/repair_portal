# repair_portal/instrument_profile/doctype/service_logs/service_logs.py
# Date Updated: 2025-06-16
# Version: 1.0
# Purpose: Controller for Service Logs child table

from frappe.model.document import Document


class ServiceLogs(Document):
    pass
