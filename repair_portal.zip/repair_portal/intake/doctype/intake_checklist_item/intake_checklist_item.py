"""
Intake Checklist Item (Child Table)
Version 1.0
Last Updated: 2025-06-08

Defines checklist items to be reviewed during instrument intake process.
"""

from frappe.model.document import Document


class IntakeChecklistItem(Document):
    pass
