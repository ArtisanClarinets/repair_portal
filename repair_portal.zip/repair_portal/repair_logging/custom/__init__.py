"""
repair_logging/custom/__init__.py
Custom Scripts Init
Version 1.0
Last Updated: 2025-06-09

Initializes the custom client-side scripts used for extending core DocTypes with timeline filters for Customer and Item interactions.
"""
