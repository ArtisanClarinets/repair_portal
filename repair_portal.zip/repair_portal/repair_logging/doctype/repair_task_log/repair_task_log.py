"""
/repair_logging/doctype/repair_task_log/repair_task_log.py
Created: 2025-06-16
Version: 1.0
Purpose: Controller for Repair Task Log (child table)
"""

from frappe.model.document import Document


class RepairTaskLog(Document):
    pass
