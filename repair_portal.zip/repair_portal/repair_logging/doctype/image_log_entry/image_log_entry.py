# repair_portal/image_log/doctype/image_log_entry/image_log_entry.py
# Date Updated: 2025-06-16
# Version: 1.0
# Purpose: Controller for Image Log Entry table Doctype

from frappe.model.document import Document


class ImageLogEntry(Document):
    pass
