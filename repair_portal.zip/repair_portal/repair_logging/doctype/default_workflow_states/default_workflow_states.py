# repair_portal/repair_logging/doctype/default_workflow_states/default_workflow_states.py
# Date Updated: 2025-06-16
# Version: 1.0
# Purpose: Controller for Default Workflow States child table

from frappe.model.document import Document


class DefaultWorkflowStates(Document):
    pass
