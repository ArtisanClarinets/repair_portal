# repair_portal/service_planning/doctype/workflow_state_mapping/workflow_state_mapping.py
# Date Updated: 2025-06-16
# Version: 1.0
# Purpose: Controller for Workflow State Mapping child Doctype

from frappe.model.document import Document


class WorkflowStateMapping(Document):
    pass
