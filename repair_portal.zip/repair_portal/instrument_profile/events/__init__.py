# ---------------------------------------------------------------------------
# File: repair_portal/instrument_profile/events/__init__.py
# Date Updated: 2025-07-02
# Version: v1.0
# Purpose: Marks events as a Python package.
# ---------------------------------------------------------------------------
