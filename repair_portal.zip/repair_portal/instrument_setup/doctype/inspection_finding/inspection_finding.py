# File: repair_portal/repair_portal/instrument_setup/doctype/inspection_finding/inspection_finding.py
# Updated: 2025-06-12
# Version: 1.1
# Purpose: Clarinet Inspection Finding (Child Table); tracks inspection issues and recommended actions

from frappe.model.document import Document


class InspectionFinding(Document):
    pass
