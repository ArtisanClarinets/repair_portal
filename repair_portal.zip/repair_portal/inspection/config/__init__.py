# File: repair_portal/inspection/config/__init__.py
# Updated: 2025-06-27
# Purpose: Package marker for Inspection module config.
