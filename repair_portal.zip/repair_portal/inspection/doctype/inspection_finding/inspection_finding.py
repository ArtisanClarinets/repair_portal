"""
File: repair_portal/inspection/doctype/inspection_finding/inspection_finding.py
Updated: 2025-06-16
Version: 1.0.0
Purpose: Python controller for Inspection Finding DocType (Table, istable=1)
"""

from frappe.model.document import Document


class InspectionFinding(Document):
    pass
