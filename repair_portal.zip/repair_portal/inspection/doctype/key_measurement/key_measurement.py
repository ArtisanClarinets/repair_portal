# File: repair_portal/inspection/doctype/key_measurement/key_measurement.py
# Updated: 2025-06-16
# Version: 1.0
# Purpose: Child table for individual key/pad measurements during inspection

from frappe.model.document import Document


class KeyMeasurement(Document):
    pass
