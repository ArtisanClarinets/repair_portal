# Copyright (c) 2025, MRW Artisan Instruments and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestClientProfile(FrappeTestCase):
    pass
