### [2025-07-03] Added Clarinet Inspection DocType
- Added new DocType: Clarinet Inspection (parent, links Inspection Finding as child)
- Scaffolded clarinet_inspection.json and clarinet_inspection.py in instrument_setup/doctype
- Prepping to update Clarinet Initial Setup linkage
