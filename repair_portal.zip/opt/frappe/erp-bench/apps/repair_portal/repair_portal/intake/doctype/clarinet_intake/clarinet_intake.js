frappe.ui.form.on('Clarinet Intake', {
  onload(frm) {
    if (!frm.doc.intake_type) {
      frm.set_value('intake_type', 'Inventory');
    }
    if (frm.doc.intake_type === 'Inventory') {
      if (!frm.doc.stock_status) {
        frm.set_value('stock_status', 'Inspection');
      }
      // Defensive: only set inspected_by if valid and not Guest
      if (!frm.doc.inspected_by && frappe.session.user && frappe.session.user !== "Guest") {
        frm.set_value('inspected_by', frappe.session.user);
      }
    } else {
      if (!frm.doc.repair_status) {
        frm.set_value('repair_status', 'Pending');
      }
    }
  },

  refresh(frm) {
    if (!frm.doc.intake_type) {
      frm.set_value('intake_type', 'Inventory');
    }

    if (frm.doc.workflow_state) {
      frm.dashboard.add_indicator(
        __('Workflow: {0}', [frm.doc.workflow_state]),
        'blue'
      );
    }

    // Instrument Profile UI
    if (frm.doc.instrument_profile && frm.doc.__unsaved === false) {
      frappe.show_alert({
        message: __('Instrument Profile: {0}', [frm.doc.instrument_profile]),
        indicator: 'green'
      });
    }

    // === Custom Intake Inspection integration ===
    if (frm.doc.name) {
      frappe.call({
        method: "frappe.client.get_list",
        args: {
          doctype: "Intake Inspection",
          fields: ["name", "status"],
          filters: { clarinet_intake: frm.doc.name },
          limit_page_length: 1
        },
        callback: function(r) {
          if (r.message && r.message.length) {
            const inspection = r.message[0];
            frm.dashboard.add_indicator(
              __('QC: {0}', [inspection.status]),
              inspection.status === "Passed" ? "green" : "orange"
            );
            frm.add_custom_button(__('View Intake Inspection'), function() {
              frappe.set_route('Form', 'Intake Inspection', inspection.name);
            }, __('Quality Control'));
          }
        }
      });
    }
    // === End custom integration ===

    // (Legacy ERPNext) Quality Inspection button
    if (frm.doc.quality_inspection) {
      frm.add_custom_button(__('View Quality Inspection'), () => {
        frappe.set_route('Form', 'Quality Inspection', frm.doc.quality_inspection);
      });
    } else if (frm.doc.docstatus === 1 && frm.doc.intake_type === 'Inventory') {
      frm.add_custom_button(__('Create Quality Inspection'), () => {
        frappe.call({
          method: 'erpnext.stock.doctype.quality_inspection.quality_inspection.make_quality_inspection',
          args: {
            reference_type: 'Clarinet Intake',
            reference_name: frm.doc.name,
            item_code: frm.doc.item_code,
            inspection_type: 'Incoming'
          },
          callback(r) {
            if (r.message) {
              frappe.set_route('Form', 'Quality Inspection', r.message);
            }
          }
        });
      });
    }
  },

  intake_type(frm) {
    const isRepair = frm.doc.intake_type === 'Repair';
    frm.set_df_property('purchase_order', 'reqd', !isRepair);
    frm.set_df_property('warehouse', 'reqd', !isRepair);
    frm.set_df_property('customer', 'reqd', isRepair);
    frm.set_df_property('due_date', 'reqd', isRepair);
    if (!isRepair) {
      if (!frm.doc.stock_status) {
        frm.set_value('stock_status', 'Inspection');
      }
      // Defensive: only set inspected_by if valid and not Guest
      if (!frm.doc.inspected_by && frappe.session.user && frappe.session.user !== "Guest") {
        frm.set_value('inspected_by', frappe.session.user);
      }
    } else {
      if (!frm.doc.repair_status) {
        frm.set_value('repair_status', 'Pending');
      }
    }
  },

  validate(frm) {
    if (frm.doc.checklist && frm.doc.checklist.length) {
      const incomplete = frm.doc.checklist.filter(i => i.status !== "Completed");
      if (incomplete.length) {
        frappe.throw(__('All accessories must be marked completed. Incomplete: {0}', [incomplete.map(i => i.accessory || i.item).join(', ')]));
      }
    }
    if (frm.doc.intake_type === 'Repair' && !frm.doc.customer) {
      frappe.throw(__('Customer is required for Repair intake type.'));
    }
  },

  workflow_state(frm) {
    if (frm.doc.workflow_state === "Flagged") {
      frappe.prompt([
        {
          label: __("Escalation Reason"),
          fieldname: "flagged_reason",
          fieldtype: "Small Text",
          reqd: 1
        }
      ],
      (values) => {
        frm.set_value("flagged_reason", values.flagged_reason);
        frappe.msgprint(__('Reason captured. Escalation will be logged and managers notified.'));
      },
      __("Flag Intake"), __("Submit"));
    }
  }
});
