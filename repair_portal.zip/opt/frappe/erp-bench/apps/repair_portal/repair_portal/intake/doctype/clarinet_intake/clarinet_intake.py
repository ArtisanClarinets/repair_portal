# File Header Template
# Relative Path: repair_portal/intake/doctype/clarinet_intake/clarinet_intake.py
# Last Updated: 2025-07-05
# Version: v2.1
# Purpose: Clarinet Intake DocType controller — validation, automation,
#          workflow rules, and customer notifications.
#          v2.1 adds a safe-owner fallback so inserts never fail when the
#          session user is not (yet) a valid System User.
# Dependencies: frappe, repair_portal.logger, repair_portal.intake.utils.emailer

from __future__ import annotations

from typing import List, Dict, Tuple, TYPE_CHECKING

import frappe
from frappe import _
from frappe.model.document import Document

from . import clarinet_intake_block_flagged
from repair_portal.intake.utils.emailer import queue_intake_status_email
from repair_portal.logger import get_logger

if TYPE_CHECKING:  # pragma: no cover
    from frappe.model.document import Document

LOGGER = get_logger()

# --------------------------------------------------------------------------- #
#  Constants & Helpers
# --------------------------------------------------------------------------- #
ADMIN_USER = "Administrator"


def _get_valid_user(user_id: str | None) -> str:
    """Return *user_id* if it exists, else ``Administrator``."""
    if user_id and frappe.db.exists("User", user_id):
        return user_id
    return ADMIN_USER


# --------------------------------------------------------------------------- #
#  Workflow metadata pulled once at import – cached thereafter
# --------------------------------------------------------------------------- #
try:
    _workflow = frappe.get_doc("Workflow", "Clarinet Intake Workflow")
    _states = _workflow.states or []
    _valid_states = {row.state for row in _states}
except frappe.DoesNotExistError:
    _states: List = []
    _valid_states: set[str] = set()

# --------------------------------------------------------------------------- #
#  Main DocType class
# --------------------------------------------------------------------------- #
class ClarinetIntake(Document):
    """Controller for Clarinet Intake records."""

    # ---------------------------- Lifecycle Hooks ------------------------- #

    # ---- Save flow ----
    def validate(self) -> None:
        clarinet_intake_block_flagged.before_save(self)
        self._ensure_instrument_profile()
        if self.intake_type == "Inventory":
            self._ensure_quality_inspection()
        self._validate_checklist_complete()
        self._validate_workflow_state()

    def before_insert(self) -> None:
        # Ensure document owner is always a valid System User
        self.owner = _get_valid_user(frappe.session.user)
        self._check_write_permissions()

    # ---- Submit flow ----
    def before_submit(self) -> None:
        if self.intake_type == "Inventory" and not self.checklist:
            frappe.throw(
                _("QC Checklist must be completed before submitting this Intake.")
            )
        self._validate_checklist_complete()
        self._check_submit_permissions()

    def before_cancel(self) -> None:
        self._check_cancel_permissions()

    def on_submit(self) -> None:
        """Auto-create linked records and notify the customer."""
        if self.intake_type == "Inventory":
            self._ensure_quality_inspection()
            self._ensure_stock_entry()
            self._ensure_inspection_report()
        self.notify_customer(event="submitted")

    def on_update_after_submit(self) -> None:
        # Re-notify customer on workflow state transitions after submission
        self.notify_customer(event="state_change")

    # ------------------------ Public helper: notification ----------------- #
    def notify_customer(self, event: str = "state_change") -> None:
        """Queue a background job to email the customer (non-blocking)."""
        if not self.customer:
            return
        frappe.enqueue(
            queue_intake_status_email,
            intake_name=self.name,
            event=event,
            job_name=f"clarinet_intake_notify_{self.name}_{event}",
            enqueue_after_commit=True,
        )
        LOGGER.debug(
            "Enqueued customer notification for Intake %s (event=%s)",
            self.name,
            event,
        )

    # --------------------------------------------------------------------- #
    #                        Internal helper methods                        #
    # --------------------------------------------------------------------- #
    def _ensure_instrument_profile(self) -> None:
        if not all((self.serial_number, self.brand, self.model)):
            frappe.throw(
                _("Serial, Brand, and Model are required for Instrument Profile matching.")
            )
        filters = {
            "serial_number": self.serial_number,
            "brand": self.brand,
            "model": self.model,
        }
        existing = frappe.db.get_value("Instrument Profile", filters, "name")
        if existing:
            self.instrument_profile = existing
            LOGGER.info(
                "Linked existing Instrument Profile %s to Intake %s",
                existing,
                self.name,
            )
        else:
            profile = frappe.new_doc("Instrument Profile")
            profile.owner = _get_valid_user(frappe.session.user)
            profile.serial_number = self.serial_number
            profile.brand = self.brand
            profile.model = self.model
            profile.insert(ignore_permissions=True)
            profile.db_set("intake_id", self.name)
            self.instrument_profile = profile.name
            LOGGER.info(
                "Created Instrument Profile %s for Intake %s", profile.name, self.name
            )

    def _ensure_quality_inspection(self) -> None:
        if frappe.db.exists(
            "Quality Inspection", {"reference_name": self.name, "docstatus": 1}
        ):
            return

        inspection = frappe.new_doc("Quality Inspection")
        inspection.owner = _get_valid_user(frappe.session.user)
        inspection.update(
            {
                "inspection_type": "Incoming",
                "reference_type": "Clarinet Intake",
                "reference_name": self.name,
                "item_code": getattr(self, "item_code", None) or self.model,
                "report_date": frappe.utils.nowdate(),
                "inspected_by": _get_valid_user(frappe.session.user),
                "sample_size": 1,
                "status": "Accepted",
            }
        )
        if getattr(self, "quality_inspection_template", None):
            inspection.quality_inspection_template = self.quality_inspection_template
        inspection.insert(ignore_permissions=True)
        inspection.submit()
        self.db_set("quality_inspection", inspection.name)
        frappe.msgprint(
            _(
                "Quality Inspection <a href='/app/quality-inspection/{0}'>{0}</a> created and submitted."
            ).format(inspection.name)
        )
        LOGGER.info(
            "Quality Inspection %s created for Intake %s", inspection.name, self.name
        )

    def _ensure_stock_entry(self) -> None:
        if not self.warehouse or not self.item_code:
            frappe.throw(_("Warehouse and Item Code are required for Stock Entry."))
        if frappe.db.exists(
            "Stock Entry", {"clarinet_intake": self.name, "docstatus": 1}
        ):
            return
        se = frappe.new_doc("Stock Entry")
        se.owner = _get_valid_user(frappe.session.user)
        se.purpose = "Material Receipt"
        se.clarinet_intake = self.name
        se.company = self.company
        se.append(
            "items",
            {
                "item_code": self.item_code,
                "qty": 1,
                "t_warehouse": self.warehouse,
                "serial_no": self.serial_number,
            },
        )
        se.insert(ignore_permissions=True)
        se.submit()
        frappe.msgprint(
            _("Stock Entry <a href='/app/stock-entry/{0}'>{0}</a> created and submitted.").format(
                se.name
            )
        )
        LOGGER.info("Stock Entry %s created for Intake %s", se.name, self.name)

    def _ensure_inspection_report(self) -> None:
        if frappe.db.exists(
            "Inspection Report",
            {"serial_no": self.serial_number, "clarinet_intake": self.name},
        ):
            return
        report = frappe.new_doc("Inspection Report")
        report.owner = _get_valid_user(frappe.session.user)
        report.update(
            {
                "instrument_id": self.model,
                "serial_no": self.serial_number,
                "status": "Scheduled",
                "inspection_type": "Clarinet QA",
                "customer_name": getattr(self, "customer", ""),
                "clarinet_intake": self.name,
            }
        )
        report.insert(ignore_permissions=True)
        frappe.msgprint(
            _("Inspection Report auto-created for Serial: {0}").format(
                self.serial_number
            )
        )
        LOGGER.info("Inspection Report %s created for Intake %s", report.name, self.name)

    def _validate_checklist_complete(self) -> None:
        if not self.checklist:
            return
        incomplete = [
            row for row in self.checklist if getattr(row, "status", "") != "Completed"
        ]
        if incomplete:
            names = ", ".join(getattr(row, "accessory", "item") for row in incomplete)
            frappe.throw(
                _("All accessories must be marked completed. Incomplete: {0}").format(
                    names
                )
            )

    def _validate_workflow_state(self) -> None:
        if not _states:
            frappe.throw(_("Workflow states not found"))
        if self.workflow_state and self.workflow_state not in _valid_states:
            frappe.throw(_("Invalid workflow state: {0}").format(self.workflow_state))
        if not self.workflow_state and _states:
            self.workflow_state = _states[0].state  # default to first state

    # ------------------------------ Permissions --------------------------- #
    def _check_write_permissions(self) -> None:
        if not frappe.has_permission(self.doctype, "write"):
            frappe.throw(_("You do not have permission to save this Intake."))

    def _check_submit_permissions(self) -> None:
        if not frappe.has_permission(self.doctype, "submit"):
            frappe.throw(_("You do not have permission to submit this Intake."))

    def _check_cancel_permissions(self) -> None:
        if not frappe.has_permission(self.doctype, "cancel"):
            frappe.throw(_("You do not have permission to cancel this Intake."))

    # --------------------- Flagged escalation helper ---------------------- #
    def before_change_to_flagged(self) -> None:
        if not getattr(self, "flagged_reason", None):
            frappe.throw(_("A comment/reason is required when flagging an intake."))
        manager_emails = (
            frappe.get_all(
                "User",
                filters={"role_profile_name": "Repair Manager"},
                pluck="email",
            )
            or []
        )
        if manager_emails:
            frappe.sendmail(
                recipients=manager_emails,
                subject=_("Intake Flagged"),
                message=_("Intake {0} was flagged.<br>Reason: {1}").format(
                    self.name, frappe.bold(self.flagged_reason)
                ),
            )

    # ------------------------------- Logging ------------------------------ #
    def _log_transition(self, action: str) -> None:
        self.add_comment(
            "Comment",
            _("Workflow action '{0}' performed by {1}").format(
                action, frappe.session.user
            ),
        )
        frappe.publish_realtime(
            "clarinet_intake_workflow_action",
            {"intake_name": self.name, "action": action, "user": frappe.session.user},
            user=frappe.session.user,
        )
