# repair_portal/client_profile/__init__.py
# Declares Client Profile as a Python module for Frappe
