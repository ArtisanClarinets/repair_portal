"""
File: repair_portal/inspection/doctype/customer_external_work_log/customer_external_work_log.py
Date Updated: 2025-06-16
Version: 1.0
Purpose: Controller for Customer External Work Log child table DocType.
"""

from frappe.model.document import Document


class CustomerExternalWorkLog(Document):
    pass
