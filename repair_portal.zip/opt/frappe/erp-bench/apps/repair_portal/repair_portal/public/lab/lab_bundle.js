import Plotly from 'plotly.js-dist';
import Meyda from 'meyda';
import * as Tone from 'tone';

window.Plotly = Plotly;
window.Meyda = Meyda;
window.Tone = Tone;
