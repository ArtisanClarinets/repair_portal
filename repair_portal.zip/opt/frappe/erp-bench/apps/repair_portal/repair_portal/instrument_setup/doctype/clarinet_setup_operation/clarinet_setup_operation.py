# File: repair_portal/repair_portal/instrument_setup/doctype/clarinet_setup_operation/clarinet_setup_operation.py
# Updated: 2025-06-12
# Version: 1.1
# Purpose: Clarinet Setup Operation (Child Table) — tracks manual service tasks by section and type

from frappe.model.document import Document


class ClarinetSetupOperation(Document):
    pass
