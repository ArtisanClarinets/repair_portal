# File: repair_portal/repair_portal/instrument_setup/doctype/setup_checklist_item/setup_checklist_item.py
# Updated: 2025-06-12
# Version: 1.1
# Purpose: Setup Checklist Item for technician task tracking in Clarinet Initial Setup

from frappe.model.document import Document


class SetupChecklistItem(Document):
    pass
