# repair_portal/service_planning/doctype/tasks/tasks.py
# Date Updated: 2025-06-16
# Version: 1.0
# Purpose: Controller for Tasks child Doctype under Service Planning

from frappe.model.document import Document


class Tasks(Document):
    pass
