# File: repair_portal/service_planning/doctype/estimate_line_item/estimate_line_item.py
# Updated: 2025-06-16
# Version: 1.0
# Purpose: Child table for repair estimate breakdown of services and parts

from frappe.model.document import Document


class EstimateLineItem(Document):
    pass
