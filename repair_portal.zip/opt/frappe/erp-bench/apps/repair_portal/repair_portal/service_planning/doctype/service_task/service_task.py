"""
Service Task (Child Table)
Version 1.0
Last Updated: 2025-06-08

Defines individual actions or subtasks within a broader Service Plan.
"""

from frappe.model.document import Document


class ServiceTask(Document):
    pass
