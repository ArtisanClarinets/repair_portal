# Copyright (c) 2021, Wahni Green Technologies Pvt. Ltd. and contributors
# For license information, please see license.txt

# import frappe
import unittest


class TestCurrencyExchangeSettings(unittest.TestCase):
	pass
