from pathlib import Path
import json
import frappe

QC_NAME     = "NEW-CLARINET-INCOMING-INSPECTION"
SCHEMA_FILE = Path(__file__).parent.parent / "data" / "clarinet_qc.json"

def load_schema() -> dict:
    with SCHEMA_FILE.open() as f:
        return json.load(f)

def upsert(doctype: str, filters: dict, values: dict) -> str:
    name = frappe.db.exists(doctype, filters)
    doc  = frappe.get_doc(doctype, name) if name else frappe.new_doc(doctype)
    doc.update(values)
    try:
        (doc.save() if name else doc.insert(ignore_permissions=True))
    except frappe.MandatoryError as e:
        title = f"Failed to upsert {doctype} for {filters} ({type(e).__name__})"
        frappe.log_error(title[:140], frappe.get_traceback()[:1000])
        print(f"MANDATORY ERROR: {title} | {str(e)}")
        raise
    except Exception as e:
        title = f"Error in upsert {doctype} for {filters} ({type(e).__name__})"
        frappe.log_error(title[:140], frappe.get_traceback()[:1000])
        print(f"UNEXPECTED ERROR: {title} | {str(e)}")
        raise
    return doc.name

def sync_qc():
    data = load_schema()

    # 1. Upsert parent Quality Procedure
    proc_name = upsert(
        "Quality Procedure",
        {"name": QC_NAME},
        {
            "name": QC_NAME,
            "item_group":        data["procedure"]["item_group"],
            "default_operation": data["procedure"]["default_operation"],
            "sample_size":       data["procedure"].get("sample_size", 100),
        },
    )
    proc_doc = frappe.get_doc("Quality Procedure", proc_name)

    # 2. Upsert child table: Quality Procedure Process
    rows = getattr(proc_doc, "quality_procedure_process", [])
    idx  = {r.process_description for r in rows}

    for row in data["points"]:
        # We'll use 'parameter' as 'process_description'
        desc = row["parameter"]
        if desc in idx:
            # Update existing row if present
            r = next(r for r in rows if r.process_description == desc)
            r.procedure = None  # You may map this to something, or leave blank
        else:
            proc_doc.append("quality_procedure_process", {
                "process_description": desc,
                "procedure": None,  # Or another value if you want to map
            })
    proc_doc.save()

    frappe.db.commit()
    frappe.logger().info("Clarinet QC procedure synced ✅")

if __name__ == "__main__":
    sync_qc()
    print("QC procedure sync complete.")