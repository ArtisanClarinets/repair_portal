# File Header Template
# Relative Path: repair_portal/repair_logging/doctype/diagnostic_metrics/diagnostic_metrics.py
# Last Updated: 2025-07-06
# Version: v1.0
# Purpose: Child table to record diagnostic measurements.
# Dependencies: frappe

from frappe.model.document import Document


class DiagnosticMetrics(Document):
    pass
