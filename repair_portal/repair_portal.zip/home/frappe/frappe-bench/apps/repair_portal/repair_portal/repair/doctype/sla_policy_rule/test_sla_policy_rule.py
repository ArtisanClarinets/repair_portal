# Copyright (c) 2025, Dylan Thompson and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestSLAPolicyRule(FrappeTestCase):
	pass
