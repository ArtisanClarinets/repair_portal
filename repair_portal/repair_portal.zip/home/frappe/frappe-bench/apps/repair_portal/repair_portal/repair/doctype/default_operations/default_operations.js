// Copyright (c) 2025, DT and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Default Operations", {
// 	refresh(frm) {

// 	},
// });
