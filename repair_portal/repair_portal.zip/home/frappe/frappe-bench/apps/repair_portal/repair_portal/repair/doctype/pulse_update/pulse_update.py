# relative path: repair/doctype/pulse_update/pulse_update.py
# updated: 2025-06-27
# version: 1.0
# purpose: Controller for Pulse Update entries linked to Repair Orders.

from frappe.model.document import Document


class PulseUpdate(Document):
    pass
