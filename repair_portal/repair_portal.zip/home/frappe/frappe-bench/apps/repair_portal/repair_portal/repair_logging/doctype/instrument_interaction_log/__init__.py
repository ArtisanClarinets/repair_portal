"""
repair_logging/doctype/instrument_interaction_log/__init__.py
Instrument Interaction Log Init
Version 1.0
Last Updated: 2025-06-09

Initializes the Instrument Interaction Log doctype module.
"""
