# File Header Template
# Relative Path: repair_portal/instrument_profile/doctype/instrument_photo/__init__.py
# Last Updated: 2025-07-23
# Version: v1.0
# Purpose: Module init for Instrument Photo child table
