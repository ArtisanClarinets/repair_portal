# QA Dashboard Charts

## Charts Provided
- Pass Rate Trend (Line)
- Average ΔP Trend (Line)
- Re-service Rate (Bar)

Each chart is filterable and updated in the QA Dashboard workspace.

## Last Updated
2025-06-27
