# relative path: tools/doctype/tool_calibration_log/tool_calibration_log.py
# last updated: 2025-07-01
# version: 1.0
# purpose: Controller for Tool Calibration Log DocType.

from frappe.model.document import Document


class ToolCalibrationLog(Document):
    pass
