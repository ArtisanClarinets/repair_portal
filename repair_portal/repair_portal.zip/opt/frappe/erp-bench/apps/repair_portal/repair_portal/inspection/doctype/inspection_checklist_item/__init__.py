# File: repair_portal/inspection/doctype/inspection_checklist_item/__init__.py
# Updated: 2025-06-27
# Purpose: Marks Inspection Checklist Item as a Python module for child table use.
