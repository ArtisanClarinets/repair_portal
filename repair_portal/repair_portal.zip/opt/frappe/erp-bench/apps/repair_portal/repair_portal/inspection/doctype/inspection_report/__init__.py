# repair_portal/inspection/doctype/inspection_report/__init__.py
# Ensures migration scripts and controllers are properly loaded for bench execute.
