# File: repair_portal/repair_portal/config/__init__.py
# Updated: 2025-06-13
# Version: 1.0
# Purpose: Init file to mark config as a Python package

# No executable logic required
