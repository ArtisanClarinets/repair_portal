# repair_portal/intake/doctype/clarinet_intake/clarinet_intake.py

import frappe
from frappe import _
from frappe.model.document import Document
import frappe.utils

from . import clarinet_intake_block_flagged

# --- Workflow helpers ---
workflow = frappe.get_doc("Workflow", "Clarinet Intake Workflow")
states = workflow.states or []
valid_states = {row.state for row in states}

class ClarinetIntake(Document):
    """
    Handles validation, lifecycle hooks, and automatic related record creation.
    """

    def validate(self):
        clarinet_intake_block_flagged.before_save(self)
        self._ensure_instrument_profile()
        if self.intake_type == "Inventory":
            self._ensure_quality_inspection()
        self._validate_checklist_complete()
        self._validate_workflow_state()

    def before_insert(self):
        self._check_write_permissions()

    def before_submit(self):
        if self.intake_type == "Inventory" and not self.checklist:
            frappe.throw(_("QC Checklist must be completed before submitting this Intake."))
        self._validate_checklist_complete()
        self._check_submit_permissions()

    def before_cancel(self):
        self._check_cancel_permissions()

    def on_submit(self):
        """
        Automatically create a Quality Inspection and Stock Entry on submit.
        Also create a custom Inspection Report for the new workflow.
        """
        if self.intake_type == "Inventory":
            self._ensure_quality_inspection()
            self._ensure_stock_entry()
            # --- Create Inspection Report (custom QC workflow) ---
            if not frappe.db.exists("Inspection Report", {"serial_no": self.serial_number, "clarinet_intake": self.name}):
                report = frappe.new_doc("Inspection Report")
                report.instrument_id = self.model
                report.serial_no = self.serial_number
                report.status = "Scheduled"
                report.inspection_type = "Clarinet QA"
                report.customer_name = getattr(self, "customer", "")
                report.clarinet_intake = self.name
                report.save(ignore_permissions=True)
                frappe.msgprint(f"Inspection Report auto-created for Serial: {self.serial_number}")
        self.notify_customer(event="submitted")

    def on_update_after_submit(self):
        # Send notifications on state change or repair completion
        self.notify_customer(event="state_change")

    # ---- Core Implementation Starts Here ----

    def _ensure_instrument_profile(self):
        if not (self.serial_number and self.brand and self.model):
            frappe.throw(_("Serial, Brand, and Model are required for Instrument Profile matching."))
        filters = {
            "serial_number": self.serial_number,
            "brand": self.brand,
            "model": self.model
        }
        existing = frappe.db.get_value("Instrument Profile", filters, "name")
        if existing:
            self.instrument_profile = existing
        else:
            profile = frappe.new_doc("Instrument Profile")
            profile.serial_number = self.serial_number
            profile.brand = self.brand
            profile.model = self.model
            profile.intake_id = self.name
            # Copy more fields if needed (category, customer, etc.)
            profile.insert(ignore_permissions=True)
            self.instrument_profile = profile.name

    def _ensure_quality_inspection(self):
        # Defensive: ensure inspected_by is a valid user, else fallback
        inspected_by = frappe.session.user
        if not frappe.db.exists("User", inspected_by):
            inspected_by = "Administrator"
        inspection = frappe.new_doc("Quality Inspection")
        inspection.inspection_type = "Incoming"
        inspection.reference_type = "Clarinet Intake"
        inspection.reference_name = self.name
        inspection.item_code = getattr(self, "item_code", None) or self.model
        inspection.report_date = frappe.utils.nowdate()
        inspection.inspected_by = inspected_by
        inspection.sample_size = 1
        inspection.status = "Accepted"
        if getattr(self, "quality_inspection_template", None):
            inspection.quality_inspection_template = self.quality_inspection_template
        inspection.insert(ignore_permissions=True)
        inspection.submit()
        self.db_set("quality_inspection", inspection.name)
        frappe.msgprint(_(
            "Quality Inspection <a href='/app/quality-inspection/{0}'>{0}</a> created and submitted."
        ).format(inspection.name))

    def _ensure_stock_entry(self):
        if not self.warehouse or not self.item_code:
            frappe.throw(_("Warehouse and Item Code are required for Stock Entry."))
        # Prevent duplicates
        existing = frappe.db.exists("Stock Entry", {"clarinet_intake": self.name, "docstatus": 1})
        if existing:
            return
        se = frappe.new_doc("Stock Entry")
        se.purpose = "Material Receipt"
        se.clarinet_intake = self.name
        se.company = self.company
        se.append("items", {
            "item_code": self.item_code,
            "qty": 1,
            "t_warehouse": self.warehouse,
            "serial_no": self.serial_number
        })
        se.insert(ignore_permissions=True)
        se.submit()
        frappe.msgprint(_("Stock Entry <a href='/app/stock-entry/{0}'>{0}</a> created and submitted.").format(se.name))

    def notify_customer(self, event="state_change"):
        if not self.customer:
            return
        email = frappe.db.get_value("Customer", self.customer, "email_id")
        if not email:
            return
        subject = f"Your Instrument Intake Status Update: {self.name}"
        message = f"Dear Customer,<br>Your instrument {self.serial_number} is now in state: {self.workflow_state}.<br>Please log in to your portal for details."
        frappe.sendmail(recipients=[email], subject=subject, message=message)

    def _validate_checklist_complete(self):
        if self.checklist:
            incomplete = [row for row in self.checklist if row.status != "Completed"]
            if incomplete:
                names = ', '.join([getattr(row, 'accessory', 'item') for row in incomplete])
                frappe.throw(_("All accessories must be marked completed. Incomplete: {0}").format(names))

    def _validate_workflow_state(self):
        if not states:
            frappe.throw(_("Workflow states not found"))
        if self.workflow_state and self.workflow_state not in valid_states:
            frappe.throw(_("Invalid workflow state: {0}").format(self.workflow_state))
        if not self.workflow_state and states:
            self.workflow_state = states[0].state

    def _check_write_permissions(self):
        if not frappe.has_permission(self.doctype, "write"):
            frappe.throw(_("You do not have permission to save this Intake."))

    def _check_submit_permissions(self):
        if not frappe.has_permission(self.doctype, "submit"):
            frappe.throw(_("You do not have permission to submit this Intake."))

    def _check_cancel_permissions(self):
        if not frappe.has_permission(self.doctype, "cancel"):
            frappe.throw(_("You do not have permission to cancel this Intake."))

    # --- Flagged Escalation ---
    def before_change_to_flagged(self):
        if not getattr(self, "flagged_reason", None):
            frappe.throw(_("A comment/reason is required when flagging an intake."))
        manager_emails = [x[0] for x in frappe.get_all("User", filters={"role_profile_name": "Repair Manager"}, pluck="email")]
        if manager_emails:
            frappe.sendmail(
                recipients=manager_emails,
                subject="Intake Flagged",
                message=f"Intake {self.name} was flagged.<br>Reason: {self.flagged_reason}"
            )
        # Optionally: schedule escalation task/job here

    def _log_transition(self, action: str):
        self.add_comment("Comment", _(f"Workflow action '{action}' performed by {frappe.session.user}"))
        frappe.publish_realtime(
            "clarinet_intake_workflow_action",
            {"intake_name": self.name, "action": action, "user": frappe.session.user},
            user=frappe.session.user,
        )
