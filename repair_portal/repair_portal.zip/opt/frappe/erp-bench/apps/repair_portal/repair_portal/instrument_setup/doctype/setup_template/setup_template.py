# File: repair_portal/repair_portal/instrument_setup/doctype/setup_template/setup_template.py
# Updated: 2025-06-12
# Version: 1.1
# Purpose: Setup Template for reusable checklists per clarinet model in service workflows

from frappe.model.document import Document


class SetupTemplate(Document):
    pass
