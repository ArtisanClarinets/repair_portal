# File: repair_portal/repair_portal/doctype/qa_checklist_item/qa_checklist_item.py
# Updated: 2025-06-16
# Version: 1.0
# Purpose: Controller for QA Checklist Item child table

from frappe.model.document import Document


class QaChecklistItem(Document):
    pass
