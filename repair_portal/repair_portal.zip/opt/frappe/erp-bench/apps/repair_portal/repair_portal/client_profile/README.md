# Client Profile Module

## Update Log

### 2025-06-30: Notes Field Clarification
- Renamed `notes` to `technician_notes` (Text Editor, internal only).
- Permissions and description updated for clear internal use.
- No change required in controllers, workflows, or client_profile.js logic.
