# File: repair_portal/instrument_profile/doctype/__init__.py
# Updated: 2025-06-26
# Version: 1.0
# Purpose: Enable Python package import for doctype submodules
