# File: repair_portal/repair_portal/doctype/repair_note/repair_note.py
# Updated: 2025-06-16
# Version: 1.0
# Purpose: Controller for child table Repair Note

from frappe.model.document import Document


class RepairNote(Document):
    pass
