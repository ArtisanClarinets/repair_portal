### [2025-07-03] Linked Clarinet Initial Setup to Clarinet Inspection
- Updated inspection field in Clarinet Initial Setup to use new Clarinet Inspection DocType
