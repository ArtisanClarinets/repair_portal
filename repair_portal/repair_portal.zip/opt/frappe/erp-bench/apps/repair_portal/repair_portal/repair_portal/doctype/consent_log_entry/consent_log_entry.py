"""
Path: repair_portal/repair_portal/doctype/consent_log_entry/consent_log_entry.py
Date: 2025-06-16
Version: 1.0
Purpose: Server-side logic for Consent Log Entry child table
"""

from frappe.model.document import Document


class ConsentLogEntry(Document):
    pass
