# File: repair_portal/repair_portal/doctype/repair_note/__init__.py
# Created: 2025-06-16
# Purpose: Init file to mark repair_note as Python package
