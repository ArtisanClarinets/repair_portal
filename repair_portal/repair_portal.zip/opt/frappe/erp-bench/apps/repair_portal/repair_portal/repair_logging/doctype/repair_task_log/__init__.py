# /repair_logging/doctype/repair_task_log/__init__.py
# Created: 2025-06-16
# Version: 1.0
# Purpose: Initialize Repair Task Log DocType package
